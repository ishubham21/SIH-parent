const Data = [
  {
    id: 1,
    Image:[ "../../assets/AverageDailyIntake_Toddler.svg"],
  },

];
export default Data;
