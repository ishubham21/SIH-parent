import style from "./ChildInfoDiv.module.css";

const ChildInfoDiv = () => {
  return <div className={style.child_info_div}></div>;
};

export default ChildInfoDiv;
