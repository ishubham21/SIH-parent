import Dashboard from "../Dashboard/Dashboard";
import Login from "../Login/Login";
import Progress from "../Progress/Progress";
import Signup from "../Signup/Signup";
import About from "../About/About";
import style from "./App.module.css";
import Milestones from "../Milestones/Milestones";
import DietChart from "../../components/DietChart/DietChart";
import Gallery from "../Gallery/Gallery";

const App = () => {
  return (
    <>
      <Gallery />
    </>
  );
};

export default App;
