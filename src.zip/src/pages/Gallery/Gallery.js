import style from "./Gallery.module.css";
import { useEffect } from "react";
import Navbar from "../../components/Navbar/Navbar";

const Gallery = () => {

    useEffect(() => {
        document.documentElement.style.setProperty(
          "--navbar-button",
          "#A390FB",
        );
      }, []);

    return(
        <div className={style.gallery}>
             <div className={style.navbar}>
        <Navbar />
      </div>
            <div className={style.wrapper}>
                <p className={style.heading}>VIRTUAL GALLERY TO CHERISH YOUR MEMORIES</p>
                <div className={style.imgWrapper}>
                <div className={style.img_div}>
                    <img
                    src = {require("../../assets/galleryimg1.jpeg")}
                    alt=""
                    className={style.img}/>
                </div>
                <div className={style.img_div}>
                    <img
                    src = {require("../../assets/galleryimg2.jpeg")}
                    alt =""
                    className={style.img}/>
                </div>
                </div>
            </div>
        </div>
    );
};

export default Gallery;